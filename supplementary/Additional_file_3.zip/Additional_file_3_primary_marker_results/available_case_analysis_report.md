# Available-case and selection analysis

## Data extraction checks

- Read-only source: local MIMIC-IV PostgreSQL, database `mimic`, PostgreSQL 17.
- Eligible roster: 2,376 hospital stays and 181 deaths.
- Complete five-index cases: 879 stays and 87 deaths.
- Candidate panel export: 2,188 qualifying panels from 886 unique stays. Panels were retained to select comparison-specific specimens.
- The selected common five-index records matched the frozen `cbc_export_v2.csv` for all 879 hospital stays, including ANC, ALC, AMC, platelet count, and the all-absolute flag.

## Missingness breakdown

| Group | Stays | Deaths | Mortality |
|---|---:|---:|---:|
| Full eligible cohort | 2,376 | 181 | 7.62% |
| No qualifying same-panel ANC/ALC/platelet results | 1,490 | 94 | 6.31% |
| NLR/SII panel available, monocyte unavailable | 7 | 0 | 0.00% |
| All five indices available | 879 | 87 | 9.90% |

Complete vs non-complete groups differed in admission-type distribution (Monte Carlo Fisher p<0.001) and mortality (9.90% vs 6.28%, p=0.00175). Age (p=0.0675), Charlson score (p=0.388), and sex (p=0.147) did not show evidence of a difference in the reported comparisons.

## Per-comparison available cases

Delta is defined as AUC(platelet-containing) minus AUC(platelet-free), so negative values favor the platelet-free comparator.

| Comparison | n | Events | AUC free | AUC containing | ΔAUC | Bootstrap 95% CI | DeLong p | BH-FDR |
|---|---:|---:|---:|---:|---:|---|---:|---:|
| NLR vs SII | 886 | 87 | 0.6823 | 0.5729 | −0.1094 | −0.1512 to −0.0676 | 6.17e-07 | 6.17e-07 |
| SIRI vs PIV | 879 | 87 | 0.6606 | 0.5731 | −0.0874 | −0.1203 to −0.0571 | 1.15e-07 | 2.29e-07 |

On the common 879-stay/87-event sample, estimates reproduced the frozen main analysis: ΔAUC −0.1089 for SII vs NLR and −0.0874 for PIV vs SIRI.

Descriptive available-case PLR vs inverse lymphocyte comparison: n=886, 87 events, AUC 0.5337 vs 0.6775, ΔAUC −0.1438 (95% bootstrap CI −0.2052 to −0.0906; paired DeLong p=5.66e-07).

## Dependence and sensitivity analyses

- Subject-clustered bootstrap in the common sample (879 stays, 877 subjects): SII vs NLR 95% CI −0.1537 to −0.0671; PIV vs SIRI −0.1206 to −0.0547.
- First stay per subject (877 stays, 87 events): ΔAUC −0.1096 and −0.0880.
- Emergency/urgent admission types (636 stays, 60 events): ΔAUC −0.0557 (95% CI −0.1014 to −0.0160; p=0.0110) and −0.0600 (−0.0966 to −0.0225; p=0.0021).
- Explicit ELECTIVE stratum had 13 stays and 5 events; 230 additional stays were in other/unclassified admission types. Elective-stratum discrimination was not estimated because of the small sample.
- Platelet tertile mortality was 18.09%, 4.44%, and 7.17% from low to high tertiles. Restricted cubic spline logistic fit showed a nonlinear term p=0.0003; this is an exploratory association, not a causal analysis.
- Among the common 879 cases, 409 had all absolute differential counts and 470 had at least one percentage-derived count.

## Interpretation boundary

Available-case sample sizes were 886/2,376 (37.3%) and 879/2,376 (37.0%). Similar estimates across per-comparison and common samples reduce concern that the monocyte requirement alone explains the result, but do not eliminate selection bias from missing differential panels. Inverse-probability weighting was not performed.
