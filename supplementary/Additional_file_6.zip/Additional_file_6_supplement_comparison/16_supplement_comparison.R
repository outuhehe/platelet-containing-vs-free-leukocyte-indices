# Comparison-driven analyses with repeated, subject-grouped cross-validation.
ROOT <- normalizePath(Sys.getenv("FRONTMED_PROJECT_ROOT", unset = "."), winslash = "/", mustWork = TRUE)
RA <- Sys.getenv("RA_ROOT", unset = file.path(ROOT, "reproducible_analysis"))
.libPaths(c(file.path(RA, "Rlib"), .libPaths()))
suppressPackageStartupMessages(library(pROC))
TAB <- Sys.getenv("FRONTMED_TABLE_DIR", unset = file.path(RA, "outputs", "tables"))
dir.create(TAB, recursive = TRUE, showWarnings = FALSE)
INT <- file.path(RA, "outputs", "interim")
set.seed(20261120)
AUC <- function(y, p) as.numeric(auc(roc(y, p, direction = "<", quiet = TRUE)))

Sys.setenv(RA_ROOT = RA)
source(file.path(RA, "R", "00_common.R"))
con <- connect_eicu()

# eICU diagnosis codes are only a proxy; explicit exclusion diagnoses take priority.
val <- read.csv(file.path(RA, "outputs", "tables", "eicu_sicu_external_validation_dataset.csv"), check.names = FALSE)
val <- val[val$values_valid == TRUE & val$outcome_available == TRUE & val$alc > 0, ]
ids <- unique(val$patientunitstayid)
dx <- dbGetQuery(con, sprintf("SELECT patientunitstayid, icd9code FROM eicu_crd.diagnosis WHERE patientunitstayid IN (%s)",
                              paste(as.integer(ids), collapse = ",")))
dbDisconnect(con)
code <- gsub("\\.", "", trimws(dx$icd9code))
abd_include <- grepl("^15[1-7]", code) | grepl("^560", code) | grepl("^562", code) |
  grepl("^56983", code) | grepl("^576", code) | grepl("^557", code) | grepl("^86[3-8]", code)
abd_exclude <- grepl("^540", code) | grepl("^574", code) | grepl("^575", code)
flags <- aggregate(cbind(abd_include, abd_exclude) ~ patientunitstayid,
                   data = data.frame(patientunitstayid = dx$patientunitstayid,
                                     abd_include = abd_include, abd_exclude = abd_exclude),
                   FUN = any)
flag_row <- match(val$patientunitstayid, flags$patientunitstayid)
val$abd_dx <- FALSE
matched <- !is.na(flag_row)
val$abd_dx[matched] <- flags$abd_include[flag_row[matched]] & !flags$abd_exclude[flag_row[matched]]
dx_counts <- data.frame(
  group = c("eligible_sicu", "any_inclusion_code", "any_exclusion_code", "restricted_after_exclusion_priority"),
  patients = c(nrow(val), sum(val$patientunitstayid %in% flags$patientunitstayid[flags$abd_include]),
               sum(val$patientunitstayid %in% flags$patientunitstayid[flags$abd_exclude]), sum(val$abd_dx)),
  deaths = c(sum(val$death),
             sum(val$death[val$patientunitstayid %in% flags$patientunitstayid[flags$abd_include]]),
             sum(val$death[val$patientunitstayid %in% flags$patientunitstayid[flags$abd_exclude]]),
             sum(val$death[val$abd_dx]))
)
write.csv(dx_counts, file.path(TAB, "supplement_eicu_dx_counts.csv"), row.names = FALSE)

paired_boot <- function(d, free, cont, B = 2000) {
  r1 <- roc(d$death, d[[free]], direction = "<", quiet = TRUE)
  r2 <- roc(d$death, d[[cont]], direction = "<", quiet = TRUE)
  dl <- roc.test(r1, r2, method = "delong")
  delta <- as.numeric(auc(r1) - auc(r2))
  bs <- replicate(B, {
    i <- unlist(lapply(split(seq_len(nrow(d)), d$death), function(ix) sample(ix, length(ix), replace = TRUE)))
    AUC(d$death[i], d[[free]][i]) - AUC(d$death[i], d[[cont]][i])
  })
  c(delta = delta, lo = quantile(bs, .025), hi = quantile(bs, .975), p = dl$p.value)
}
resB <- list()
for (nm in c("all_sicu", "abd_dx_restricted")) {
  d <- if (nm == "all_sicu") val else val[val$abd_dx, ]
  a <- paired_boot(d, "NLR", "SII")
  b <- paired_boot(d, "SIRI", "PIV")
  resB[[nm]] <- data.frame(cohort = nm, n = nrow(d), events = sum(d$death),
    delta_AUC_free_minus_cont_NLR_SII = a[1], lo_NLR_SII = a[2], hi_NLR_SII = a[3], p_NLR_SII = a[4],
    delta_AUC_free_minus_cont_SIRI_PIV = b[1], lo_SIRI_PIV = b[2], hi_SIRI_PIV = b[3], p_SIRI_PIV = b[4])
}
resB <- do.call(rbind, resB)
write.csv(resB, file.path(TAB, "supplement_eicu_dx_restricted.csv"), row.names = FALSE)

ro <- read.csv(file.path(INT, "cohort_roster_2376.csv"), check.names = FALSE)
ex <- read.csv(file.path(INT, "cbc_export_v2.csv"), check.names = FALSE)
ex <- merge(ex, ro[, c("hadm_id", "admission_type")], by = "hadm_id", all.x = TRUE)
aci <- read.csv(file.path(INT, "cbc_available_case_index.csv"), check.names = FALSE)
aci <- merge(aci, ro[, c("hadm_id", "admission_type", "sex", "age", "charlson", "subject_id")],
             by = "hadm_id", all.x = TRUE)
aci$admission_type <- factor(aci$admission_type)
aci$sex <- factor(aci$sex)
aci$death <- aci$hospital_expire_flag
collapse_adm <- function(x) factor(ifelse(grepl("EMER", x, ignore.case = TRUE), "emergency",
                                   ifelse(grepl("ELECTIVE", x, ignore.case = TRUE), "elective", "other")))
aci$adm_grp <- collapse_adm(aci$admission_type)
base_f <- death ~ age + sex + adm_grp + charlson

# Correlation is not agreement; add concordance and log-scale ratio limits.
agr_ex <- read.csv(file.path(INT, "cbc_export_v2.csv"), check.names = FALSE)
rawcol <- c(anc = 14, alc = 15, amc = 16)
pctcol <- c(anc = 17, alc = 18, amc = 19)
agr <- lapply(names(rawcol), function(cell) {
  measured <- suppressWarnings(as.numeric(agr_ex[[rawcol[cell]]]))
  estimated <- agr_ex[[20]] * agr_ex[[pctcol[cell]]] / 100
  ok <- is.finite(measured) & is.finite(estimated) & measured > 0 & estimated > 0
  x <- measured[ok]
  y <- estimated[ok]
  log_ratio <- log(y / x)
  ratio_mean <- mean(log_ratio)
  ratio_sd <- sd(log_ratio)
  data.frame(cell = cell, n = length(x), pearson_r = cor(x, y),
    lin_ccc = 2 * cov(x, y) / (var(x) + var(y) + (mean(x) - mean(y))^2),
    geometric_mean_ratio = exp(ratio_mean),
    ratio_loa_lower = exp(ratio_mean - 1.96 * ratio_sd),
    ratio_loa_upper = exp(ratio_mean + 1.96 * ratio_sd))
})
agr <- do.call(rbind, agr)
write.csv(agr, file.path(TAB, "supplement_count_agreement.csv"), row.names = FALSE)

grouped_folds <- function(y, subject_id, K = 10) {
  group_event <- tapply(y, factor(subject_id, levels = unique(subject_id)), max)
  fold_by_id <- setNames(rep(NA_integer_, length(group_event)), names(group_event))
  for (event_status in c(0, 1)) {
    ids <- sample(names(group_event)[group_event == event_status])
    fold_by_id[ids] <- rep(seq_len(K), length.out = length(ids))
  }
  unname(fold_by_id[as.character(subject_id)])
}

run_repeated_cv <- function(d, indexes, repeats = 20, K = 10) {
  for (idx in indexes) d[[paste0("log_", idx)]] <- log(d[[idx]])
  forms <- list(base = base_f)
  for (idx in indexes) {
    nm <- paste0("add_", toupper(idx))
    forms[[nm]] <- as.formula(paste0("death ~ age + sex + adm_grp + charlson + log_", idx))
  }
  pred <- lapply(forms, function(x) matrix(NA_real_, nrow(d), repeats))
  lp <- lapply(forms, function(x) matrix(NA_real_, nrow(d), repeats))
  for (r in seq_len(repeats)) {
    folds <- grouped_folds(d$death, d$subject_id, K)
    for (k in seq_len(K)) {
      train <- d[folds != k, ]
      test <- d[folds == k, ]
      for (nm in names(forms)) {
        fit <- glm(forms[[nm]], family = binomial, data = train)
        pred[[nm]][folds == k, r] <- predict(fit, newdata = test, type = "response")
        lp[[nm]][folds == k, r] <- predict(fit, newdata = test, type = "link")
      }
    }
  }
  aucs <- sapply(names(forms), function(nm) vapply(seq_len(repeats), function(r) AUC(d$death, pred[[nm]][, r]), numeric(1)))
  list(data = d, forms = forms, pred = pred, lp = lp, auc = aucs, repeats = repeats)
}

# Incremental discrimination: out-of-fold AUCs; the LRT tests added model fit only.
inc <- list()
for (spec in list(c("nlr", "sii"), c("siri", "piv"))) {
  d <- aci[is.finite(aci[[spec[1]]]) & is.finite(aci[[spec[2]]]), ]
  cv <- run_repeated_cv(d, spec)
  m0 <- glm(base_f, family = binomial, data = d)
  for (idx in spec) {
    log_name <- paste0("log_", idx)
    d[[log_name]] <- log(d[[idx]])
    m1 <- glm(update(base_f, as.formula(paste(". ~ . +", log_name))), family = binomial, data = d)
    lrt_p <- anova(m0, m1, test = "Chisq")$`Pr(>Chi)`[2]
    nm <- paste0("add_", toupper(idx))
    delta <- cv$auc[, nm] - cv$auc[, "base"]
    inc[[idx]] <- data.frame(sample = paste(spec, collapse = "/"), n = nrow(d), events = sum(d$death),
      index = toupper(idx), cv_base_auc_mean = mean(cv$auc[, "base"]), cv_base_auc_sd = sd(cv$auc[, "base"]),
      cv_added_auc_mean = mean(cv$auc[, nm]), cv_added_auc_sd = sd(cv$auc[, nm]),
      cv_delta_AUC_added_minus_base_mean = mean(delta), cv_delta_AUC_added_minus_base_sd = sd(delta), LRT_p = lrt_p)
  }
}
inc <- do.call(rbind, inc)
write.csv(inc, file.path(TAB, "supplement_incremental_base_model.csv"), row.names = FALSE)

# Calibration and DCA on the common five-index sample; 20 grouped, stratified 10-fold partitions.
d <- ex[is.finite(ex$nlr) & is.finite(ex$sii) & is.finite(ex$siri) & is.finite(ex$piv), ]
d$death <- d$hospital_expire_flag
d$admission_type <- factor(d$admission_type)
d$sex <- factor(d$sex)
d$adm_grp <- collapse_adm(d$admission_type)
cv <- run_repeated_cv(d, c("nlr", "sii", "siri", "piv"))
cal <- lapply(names(cv$pred), function(nm) {
  metric <- do.call(rbind, lapply(seq_len(cv$repeats), function(r) {
    fit <- glm(d$death ~ cv$lp[[nm]][, r], family = binomial)
    c(intercept = unname(coef(fit)[1]), slope = unname(coef(fit)[2]),
      brier = mean((cv$pred[[nm]][, r] - d$death)^2), auc = unname(cv$auc[r, nm]))
  }))
  data.frame(model = nm, n = nrow(d), events = sum(d$death),
    cal_intercept_mean = mean(metric[, "intercept"]), cal_intercept_sd = sd(metric[, "intercept"]),
    cal_slope_mean = mean(metric[, "slope"]), cal_slope_sd = sd(metric[, "slope"]),
    brier_mean = mean(metric[, "brier"]), brier_sd = sd(metric[, "brier"]),
    cv_auc_mean = mean(metric[, "auc"]), cv_auc_sd = sd(metric[, "auc"]))
})
cal <- do.call(rbind, cal)
write.csv(cal, file.path(TAB, "supplement_calibration.csv"), row.names = FALSE)

binned <- lapply(names(cv$pred), function(nm) {
  p <- rowMeans(cv$pred[[nm]])
  decile <- pmin(10L, ceiling(rank(p, ties.method = "first") / length(p) * 10))
  do.call(rbind, lapply(sort(unique(decile)), function(g) {
    i <- decile == g
    data.frame(model = nm, decile = g, pred = mean(p[i]), obs = mean(d$death[i]), n = sum(i))
  }))
})
binned <- do.call(rbind, binned)
write.csv(binned, file.path(TAB, "supplement_calibration_binned.csv"), row.names = FALSE)

nb <- function(p, y, pt) {
  tp <- sum(p >= pt & y == 1) / length(y)
  fp <- sum(p >= pt & y == 0) / length(y)
  tp - fp * pt / (1 - pt)
}
thresholds <- seq(0.05, 0.40, by = 0.01)
dca_runs <- list()
for (nm in names(cv$pred)) for (r in seq_len(cv$repeats)) for (pt in thresholds) {
  dca_runs[[length(dca_runs) + 1]] <- data.frame(model = nm, iteration = r, threshold = pt,
    net_benefit = nb(cv$pred[[nm]][, r], d$death, pt))
}
dca_runs <- do.call(rbind, dca_runs)
dca_mean <- aggregate(net_benefit ~ model + threshold, dca_runs, mean)
dca_sd <- aggregate(net_benefit ~ model + threshold, dca_runs, sd)
names(dca_mean)[3] <- "mean_net_benefit"
names(dca_sd)[3] <- "sd_net_benefit"
dca <- merge(dca_mean, dca_sd, by = c("model", "threshold"), sort = FALSE)
prev <- mean(d$death)
refs <- do.call(rbind, lapply(thresholds, function(pt) data.frame(
  model = c("treat_all", "treat_none"), threshold = pt,
  mean_net_benefit = c(prev - (1 - prev) * pt / (1 - pt), 0), sd_net_benefit = 0)))
dca <- rbind(dca, refs)
write.csv(dca, file.path(TAB, "supplement_dca.csv"), row.names = FALSE)

cat("=== count comparison ===\n"); print(agr)
cat("=== repeated-CV incremental analysis ===\n"); print(inc)
cat("=== eICU diagnosis-proxy sensitivity ===\n"); print(resB)
cat("=== diagnosis-proxy aggregate counts ===\n"); print(dx_counts)
cat("=== repeated-CV calibration ===\n"); print(cal)
cat("=== repeated-CV DCA summary ===\n"); print(head(dca))
cat("DONE\n")
