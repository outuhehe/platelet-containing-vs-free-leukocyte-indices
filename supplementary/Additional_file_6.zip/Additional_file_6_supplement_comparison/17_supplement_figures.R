# Calibration and decision-curve figure (manuscript Figure 5): repeated,
# subject-grouped 10-fold cross-validated calibration and decision curves.
ROOT <- normalizePath(Sys.getenv("STUDY_PROJECT_ROOT", unset = "."), winslash = "/", mustWork = TRUE)
RA <- Sys.getenv("RA_ROOT", unset = file.path(ROOT, "reproducible_analysis"))
PKG <- Sys.getenv("STUDY_FIGURE_DIR", unset = file.path(ROOT, "outputs", "submission_package"))
TAB <- Sys.getenv("STUDY_TABLE_DIR", unset = file.path(RA, "outputs", "tables"))
dir.create(PKG, recursive = TRUE, showWarnings = FALSE)
binned <- read.csv(file.path(TAB, "supplement_calibration_binned.csv"), check.names = FALSE)
dca <- read.csv(file.path(TAB, "supplement_dca.csv"), check.names = FALSE)
model_levels <- c("base", "add_NLR", "add_SII", "add_SIRI", "add_PIV")
labels <- c(base = "Base model", add_NLR = "Base + NLR", add_SII = "Base + SII",
            add_SIRI = "Base + SIRI", add_PIV = "Base + PIV")
cols <- c(base = "black", add_NLR = "#D55E00", add_SII = "#0072B2",
          add_SIRI = "#009E73", add_PIV = "#CC79A7")

draw <- function() {
  layout(matrix(c(1, 2, 3, 3), nrow = 2, byrow = TRUE), heights = c(4.2, 0.9))
  par(mar = c(4.2, 4.3, 2.5, 0.8), cex.axis = 0.82, cex.lab = 0.9)
  plot(0:1, 0:1, type = "n", xlim = c(0, 0.35), ylim = c(0, 0.35),
       xlab = "Mean out-of-fold predicted probability", ylab = "Observed mortality",
       main = "A  Calibration", cex.main = 1)
  abline(0, 1, lty = 2, col = "grey50")
  for (nm in model_levels) {
    b <- binned[binned$model == nm, ]
    lines(b$pred, b$obs, col = cols[nm], lwd = 2)
    points(b$pred, b$obs, col = cols[nm], pch = 16, cex = .7)
  }
  legend("topleft", legend = c(labels[model_levels], "ideal"),
         col = c(cols[model_levels], "grey50"), lwd = 2,
         lty = c(rep(1, length(model_levels)), 2), bty = "n", cex = .75)

  plot(0, 0, type = "n", xlim = c(0.05, 0.40),
       ylim = range(c(dca$mean_net_benefit, 0), finite = TRUE),
       xlab = "Threshold probability", ylab = "Mean net benefit",
       main = "B  Decision curve", cex.main = 1)
  for (nm in model_levels) {
    s <- dca[dca$model == nm, ]
    s <- s[order(s$threshold), ]
    lines(s$threshold, s$mean_net_benefit, col = cols[nm], lwd = 2)
  }
  ta <- dca[dca$model == "treat_all", ]
  ta <- ta[order(ta$threshold), ]
  lines(ta$threshold, ta$mean_net_benefit, col = "grey40", lwd = 1.5, lty = 3)
  abline(h = 0, col = "grey40", lty = 3)
  par(mar = c(0, 0, 0, 0))
  plot.new()
  legend("center", legend = c(labels[model_levels], "treat all", "treat none"),
         col = c(cols[model_levels], "grey40", "grey40"), lwd = 2,
         lty = c(rep(1, length(model_levels)), 3, 3), bty = "n", cex = .82, ncol = 4)
}

png(file.path(PKG, "Figure5_calibration_dca.png"), width = 2100, height = 1500, res = 300, pointsize = 11)
draw(); dev.off()
tiff(file.path(PKG, "Figure5_calibration_dca.tif"), width = 2100, height = 1500,
     res = 300, pointsize = 11, compression = "lzw")
draw(); dev.off()
cat("Calibration and decision-curve figure written\n")
