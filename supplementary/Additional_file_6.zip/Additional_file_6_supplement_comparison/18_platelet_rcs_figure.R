# Historical unadjusted spline; the current adjusted curve is produced in
# Additional file 7 (manuscript Figure 4).
ROOT <- normalizePath(Sys.getenv("FRONTMED_PROJECT_ROOT", unset = "."), winslash = "/", mustWork = TRUE)
RA <- Sys.getenv("RA_ROOT", unset = file.path(ROOT, "reproducible_analysis"))
PKG <- Sys.getenv("FRONTMED_FIGURE_DIR", unset = file.path(ROOT, "outputs", "submission_package"))
dir.create(PKG, recursive = TRUE, showWarnings = FALSE)
INT <- file.path(RA, "outputs", "interim")
.libPaths(c(file.path(RA, "Rlib"), .libPaths()))
suppressPackageStartupMessages(library(rms))
set.seed(20261120)

ex <- read.csv(file.path(INT, "cbc_export_v2.csv"), check.names = FALSE)
d <- ex[is.finite(ex$nlr) & is.finite(ex$sii) & is.finite(ex$siri) & is.finite(ex$piv), ]
d$y <- as.integer(d$hospital_expire_flag)
ddist <- datadist(d)
options(datadist = "ddist")
fit <- lrm(y ~ rcs(log(plt), 3), data = d, x = TRUE, y = TRUE)
grid <- seq(quantile(d$plt, .01), quantile(d$plt, .99), length.out = 200)
curve <- as.data.frame(Predict(fit, plt = grid, fun = plogis, conf.int = .95))

draw <- function() {
  yr <- range(c(0, curve$upper), finite = TRUE)
  plot(curve$plt, curve$yhat, type = "n", xlim = range(grid), ylim = yr,
       xlab = "Preoperative platelet count", ylab = "Predicted in-hospital mortality",
       main = "Restricted cubic spline")
  polygon(c(curve$plt, rev(curve$plt)), c(curve$lower, rev(curve$upper)),
          col = rgb(0.00, 0.45, 0.35, 0.18), border = NA)
  lines(curve$plt, curve$yhat, col = "#00796B", lwd = 2.5)
  # Publish only the model curve and interval, without row-level value marks.
  mtext("Unadjusted; 3 knots on log platelet count; pointwise 95% CI",
        side = 3, line = .3, cex = .8, col = "grey30")
  text(x = max(grid) - .02 * diff(range(grid)), y = yr[2] - .02 * diff(yr),
       labels = "Nonlinear term p = 0.0003", adj = c(1, 1), cex = .8, col = "grey30")
}

png(file.path(PKG, "Figure4_platelet_rcs_unadjusted.png"), width = 1800, height = 1350, res = 300)
draw(); dev.off()
tiff(file.path(PKG, "Figure4_platelet_rcs_unadjusted.tif"), width = 1800, height = 1350,
     res = 300, compression = "lzw")
draw(); dev.off()
cat("Historical unadjusted spline written separately; current adjusted figure (manuscript Figure 4) is unchanged. n =", nrow(d), "stays and", sum(d$y), "deaths\n")
