Additional file 6: comparison-driven supplementary analyses (current manuscript)

Contents and current figure mapping
- 16_supplement_comparison.R: eICU diagnosis-proxy sensitivity, incremental
  models, repeated subject-grouped cross-validation, calibration, descriptive
  decision curves and measured-versus-estimated blood-count agreement.
- 17_supplement_figures.R: rebuilds main Figure 5, stored internally as
  Figure5_calibration_dca, from aggregate results.
- 18_platelet_rcs_figure.R: rebuilds a historical unadjusted spline for audit
  only, with the separate stem Figure4_platelet_rcs_unadjusted. The current
  adjusted main Figure 4 (Figure4_platelet_rcs) is produced by script 19 in
  Additional file 7. Do not substitute the historical unadjusted figure.
- supplement_*.csv: reviewed aggregate outputs only.

Cross-validation uses 20 outcome-stratified 10-fold partitions grouped by
subject_id, keeping repeated stays in the same fold. Decision-curve estimates
are descriptive averages; partition standard deviations are not confidence
intervals. Paired delta_AUC_free_minus_cont_* means free minus containing;
incremental cv_delta_AUC_added_minus_base_* means added minus base.

In the eICU diagnosis subset, exclusion diagnoses take priority. This subset
is a sensitivity proxy, not a procedure-confirmed external validation.

Unpack Additional file 1 as reproducible_analysis/ in a local project. Run
from that project's parent or set STUDY_PROJECT_ROOT. RA_ROOT may explicitly
point to the primary package. Script 16 uses the shared read-only connection
factory, with credentials from local config/db.env or a PostgreSQL password
file. No credentials or row-level records are distributed.

Optional isolated output overrides: STUDY_TABLE_DIR for scripts 16/17;
STUDY_FIGURE_DIR for 17/18. Defaults are reproducible_analysis/outputs/tables
and outputs/submission_package. All generated CSVs in this extension are
aggregate; restricted local inputs must never be included when packaging.

Primary dependencies: DBI 1.3.0, RPostgres 1.4.10, data.table 1.18.4,
pROC 1.19.0.1, survival 3.8-3, survRM2 1.0-4. Historical spline script 18 and
Additional file 7 also use rms 8.2-0; script 19 uses ggplot2 4.0.3.
