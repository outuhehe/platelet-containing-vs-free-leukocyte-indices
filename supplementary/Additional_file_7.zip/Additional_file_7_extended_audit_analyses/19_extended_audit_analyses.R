PROJECT_ROOT <- normalizePath(Sys.getenv("FRONTMED_PROJECT_ROOT", unset = getwd()), winslash = "/", mustWork = TRUE)
RA_ROOT <- Sys.getenv("RA_ROOT", unset = file.path(PROJECT_ROOT, "reproducible_analysis"))
if (!file.exists(file.path(RA_ROOT, "R", "00_common.R"))) {
  if (file.exists(file.path(PROJECT_ROOT, "R", "00_common.R"))) RA_ROOT <- PROJECT_ROOT
  else stop("Could not find R/00_common.R; set FRONTMED_PROJECT_ROOT to the project parent")
}
.libPaths(c(file.path(RA_ROOT, "Rlib"), .libPaths()))

suppressPackageStartupMessages({
  library(data.table)
  library(pROC)
  library(rms)
  library(ggplot2)
})

DATA <- file.path(RA_ROOT, "outputs", "interim")
OUT <- Sys.getenv("FRONTMED_EXTENDED_OUT", unset = file.path(PROJECT_ROOT, "outputs", "extended_analysis"))
dir.create(OUT, recursive = TRUE, showWarnings = FALSE)
set.seed(20261120)

# The frozen export retains repeated component columns from multiple CBC panels;
# make names unique while preserving the analysis variables (nlr/sii/siri/piv/plr).
d <- fread(file.path(DATA, "cbc_export_v2.csv"), check.names = TRUE)
roster <- fread(file.path(DATA, "cohort_roster_2376.csv"), check.names = TRUE)
d <- d[is.finite(nlr) & is.finite(sii) & is.finite(siri) & is.finite(piv) & is.finite(plr)]
d <- merge(d, roster[, .(hadm_id, admission_type)], by = "hadm_id", all.x = TRUE)
d[, death := as.integer(hospital_expire_flag)]
d[, sex_f := factor(sex)]
d[, adm_grp := factor(ifelse(grepl("EMER|URGENT", admission_type, ignore.case = TRUE), "emergency_urgent",
                             ifelse(grepl("ELECTIVE", admission_type, ignore.case = TRUE), "elective", "other")))]
d[, age_grp := factor(ifelse(age < 65, "<65", ">=65"), levels = c("<65", ">=65"))]
d[, charlson_grp := factor(ifelse(charlson < 3, "<3", ">=3"), levels = c("<3", ">=3"))]
d[, all_abs_grp := factor(ifelse(all_abs, "all_absolute", "any_estimated"))]

markers <- c("nlr", "sii", "siri", "piv", "plr")
label <- c(nlr = "NLR", sii = "SII", siri = "SIRI", piv = "PIV", plr = "PLR")

# E1: unadjusted, demographic-adjusted, and demographic-plus-comorbidity OR.
or_rows <- list()
for (m in markers) {
  d[, z := as.numeric(scale(log(get(m))))]
  f0 <- death ~ z
  f1 <- death ~ z + age + sex_f + adm_grp
  f2 <- death ~ z + age + sex_f + adm_grp + charlson
  for (i in seq_along(list(f0, f1, f2))) {
    fit <- glm(list(f0, f1, f2)[[i]], data = d, family = binomial)
    est <- coef(summary(fit))["z", ]
    or_rows[[length(or_rows) + 1L]] <- data.frame(marker = label[[m]], model = paste0("M", i),
      n = nobs(fit), events = sum(d$death), OR_per_SD_log_index = exp(est["Estimate"]),
      CI_lower = exp(est["Estimate"] - 1.96 * est["Std. Error"]),
      CI_upper = exp(est["Estimate"] + 1.96 * est["Std. Error"]), p = est["Pr(>|z|)"])
  }
}
fwrite(rbindlist(or_rows), file.path(OUT, "adjusted_OR_by_index.csv"))

# E5: Youden cutoffs with bootstrap optimism correction.
cut_rows <- list(); B <- 500L
for (m in markers) {
  r <- roc(d$death, d[[m]], direction = "<", quiet = TRUE)
  cc <- coords(r, "best", best.method = "youden", ret = c("threshold", "sensitivity", "specificity"), transpose = FALSE)[1, ]
  app_y <- as.numeric(cc$sensitivity) + as.numeric(cc$specificity) - 1
  train <- test <- matrix(NA_real_, B, 3)
  for (b in seq_len(B)) {
    ix <- c(sample(which(d$death == 0), sum(d$death == 0), TRUE), sample(which(d$death == 1), sum(d$death == 1), TRUE))
    rb <- roc(d$death[ix], d[[m]][ix], direction = "<", quiet = TRUE)
    cb <- coords(rb, "best", best.method = "youden", ret = "threshold", transpose = FALSE)[1, 1]
    pred_train <- d[[m]][ix] >= cb; yb <- d$death[ix]
    # Estimate optimism by validating each bootstrap-selected cutoff in the
    # original cohort, not only in the bootstrap out-of-bag subset.
    pred_test <- d[[m]] >= cb; yt <- d$death
    sens <- function(y, p) ifelse(sum(y == 1) > 0, sum(p & y == 1) / sum(y == 1), NA_real_)
    spec <- function(y, p) ifelse(sum(y == 0) > 0, sum(!p & y == 0) / sum(y == 0), NA_real_)
    train[b, ] <- c(sens(yb, pred_train), spec(yb, pred_train), sens(yb, pred_train) + spec(yb, pred_train) - 1)
    test[b, ] <- c(sens(yt, pred_test), spec(yt, pred_test), sens(yt, pred_test) + spec(yt, pred_test) - 1)
  }
  cut_rows[[length(cut_rows) + 1L]] <- data.frame(marker = label[[m]], n = nrow(d), events = sum(d$death),
    cutoff = as.numeric(cc$threshold), apparent_sensitivity = cc$sensitivity, apparent_specificity = cc$specificity,
    apparent_youden = app_y, optimism_sensitivity = mean(train[, 1] - test[, 1], na.rm = TRUE),
    optimism_specificity = mean(train[, 2] - test[, 2], na.rm = TRUE), optimism_youden = mean(train[, 3] - test[, 3], na.rm = TRUE),
    corrected_sensitivity = cc$sensitivity - mean(train[, 1] - test[, 1], na.rm = TRUE),
    corrected_specificity = cc$specificity - mean(train[, 2] - test[, 2], na.rm = TRUE),
    corrected_youden = app_y - mean(train[, 3] - test[, 3], na.rm = TRUE), bootstrap_replicates = B)
}
fwrite(rbindlist(cut_rows), file.path(OUT, "youden_cutoffs_optimism_corrected.csv"))

# E6: adjusted restricted cubic spline for platelet count.
dd <- datadist(d); options(datadist = "dd")
fit_rcs <- lrm(death ~ rcs(log(plt), 3) + age + sex_f + adm_grp + charlson, data = d, x = TRUE, y = TRUE)
an <- anova(fit_rcs)
anova_txt <- capture.output(print(an))
writeLines(anova_txt, file.path(OUT, "adjusted_platelet_rcs_anova.txt"))
grid <- data.frame(plt = exp(seq(log(quantile(d$plt, .01)), log(quantile(d$plt, .99)), length.out = 200)),
                   age = median(d$age), sex_f = levels(d$sex_f)[1], adm_grp = levels(d$adm_grp)[1], charlson = median(d$charlson))
pred <- as.data.frame(Predict(fit_rcs, plt = grid$plt, fun = plogis, conf.int = .95))
fwrite(as.data.table(pred), file.path(OUT, "adjusted_platelet_rcs_curve.csv"))
png(file.path(OUT, "Figure4_platelet_rcs_adjusted.png"), width = 1800, height = 1350, res = 300)
plot(pred$plt, pred$yhat, type = "n", xlab = "Preoperative platelet count", ylab = "Adjusted predicted in-hospital mortality", main = "Adjusted restricted cubic spline")
polygon(c(pred$plt, rev(pred$plt)), c(pred$lower, rev(pred$upper)), col = rgb(0, .45, .35, .18), border = NA)
lines(pred$plt, pred$yhat, col = "#00796B", lwd = 3)
dev.off()
tiff(file.path(OUT, "Figure4_platelet_rcs_adjusted.tif"), width = 6, height = 4.5, units = "in", res = 300, compression = "lzw")
plot(pred$plt, pred$yhat, type = "n", xlab = "Preoperative platelet count", ylab = "Adjusted predicted in-hospital mortality", main = "Adjusted restricted cubic spline")
polygon(c(pred$plt, rev(pred$plt)), c(pred$lower, rev(pred$upper)), col = rgb(0, .45, .35, .18), border = NA)
lines(pred$plt, pred$yhat, col = "#00796B", lwd = 3)
dev.off()

# E13: subgroup paired AUCs and bootstrap interaction contrasts.
paired <- function(x, free, cont, B = 500L) {
  y <- x$death; a <- roc(y, x[[free]], direction = "<", quiet = TRUE); b <- roc(y, x[[cont]], direction = "<", quiet = TRUE)
  tt <- roc.test(a, b, paired = TRUE, method = "delong")
  i0 <- which(y == 0); i1 <- which(y == 1)
  bs <- replicate(B, { ix <- c(sample(i0, length(i0), TRUE), sample(i1, length(i1), TRUE));
    as.numeric(auc(roc(y[ix], x[[free]][ix], direction = "<", quiet = TRUE)) - auc(roc(y[ix], x[[cont]][ix], direction = "<", quiet = TRUE))) })
  c(n = nrow(x), events = sum(y), delta = as.numeric(auc(a) - auc(b)),
    lo = unname(quantile(bs, .025)), hi = unname(quantile(bs, .975)), p = tt$p.value)
}
subgroup_rows <- list(); int_rows <- list()
for (sg in c("age_grp", "sex_f", "charlson_grp", "adm_grp", "all_abs_grp")) {
  for (cmp in list(c("NLR", "nlr", "sii"), c("SIRI", "siri", "piv"))) {
    lev <- levels(d[[sg]]); lev <- lev[table(d[[sg]])[lev] > 20]
    vals <- list()
    for (lv in lev) {
      x <- d[get(sg) == lv]
      vals[[lv]] <- paired(x, cmp[2], cmp[3])
      subgroup_rows[[length(subgroup_rows) + 1L]] <- data.frame(subgroup = sg, level = lv, comparison = cmp[1],
        n = vals[[lv]]["n"], events = vals[[lv]]["events"], delta_AUC = vals[[lv]]["delta"], CI_lower = vals[[lv]]["lo"], CI_upper = vals[[lv]]["hi"], DeLong_p = vals[[lv]]["p"])
    }
    if (length(lev) == 2) {
      x1 <- d[get(sg) == lev[1]]; x2 <- d[get(sg) == lev[2]]
      diffs <- replicate(500L, {
        i1 <- c(sample(which(x1$death == 0), sum(x1$death == 0), TRUE), sample(which(x1$death == 1), sum(x1$death == 1), TRUE))
        i2 <- c(sample(which(x2$death == 0), sum(x2$death == 0), TRUE), sample(which(x2$death == 1), sum(x2$death == 1), TRUE))
        p1 <- as.numeric(auc(roc(x1$death[i1], x1[[cmp[2]]][i1], direction = "<", quiet = TRUE)) - auc(roc(x1$death[i1], x1[[cmp[3]]][i1], direction = "<", quiet = TRUE)))
        p2 <- as.numeric(auc(roc(x2$death[i2], x2[[cmp[2]]][i2], direction = "<", quiet = TRUE)) - auc(roc(x2$death[i2], x2[[cmp[3]]][i2], direction = "<", quiet = TRUE)))
        p1 - p2
      })
      int_rows[[length(int_rows) + 1L]] <- data.frame(subgroup = sg, level_1 = lev[1], level_2 = lev[2], comparison = cmp[1],
        interaction_delta_level1_minus_level2 = vals[[lev[1]]]["delta"] - vals[[lev[2]]]["delta"],
        interaction_CI_lower = quantile(diffs, .025), interaction_CI_upper = quantile(diffs, .975),
        interaction_p = 2 * min(mean(diffs <= 0), mean(diffs >= 0)), bootstrap_replicates = length(diffs))
    }
  }
}
fwrite(rbindlist(subgroup_rows), file.path(OUT, "subgroup_paired_auc.csv"))
fwrite(rbindlist(int_rows), file.path(OUT, "subgroup_interaction_bootstrap.csv"))

# Forest plots for all estimable subgroup comparisons.
sgdt <- rbindlist(subgroup_rows)
for (cmpn in unique(sgdt$comparison)) {
  z <- sgdt[comparison == cmpn]
  z[, label := paste(subgroup, level, sep = ": ")]
  z[, label := factor(label, levels = rev(label))]
  fp <- ggplot(z, aes(x = delta_AUC, y = label)) +
    geom_vline(xintercept = 0, color = "grey55", linetype = 2) +
    geom_errorbar(aes(xmin = CI_lower, xmax = CI_upper), width = 0.18,
                  orientation = "y", color = "#247A69") +
    geom_point(size = 2.2, color = "#B04A3A") +
    labs(x = "Paired delta AUC (platelet-free minus platelet-containing)", y = NULL,
         title = paste("Subgroup paired AUC:", cmpn)) +
    theme_bw(base_size = 10) + theme(panel.grid.minor = element_blank())
  ggsave(file.path(OUT, paste0("subgroup_forest_", cmpn, ".png")), fp,
         width = 8.2, height = max(4.0, 0.36 * nrow(z) + 1.4), dpi = 300)
}

# E14: median and quartile classification sensitivity for all five indices.
class_rows <- list()
for (m in markers) {
  med <- median(d[[m]], na.rm = TRUE); d[, high := as.integer(get(m) >= med)]
  fit <- glm(death ~ high, data = d, family = binomial)
  rr <- coef(summary(fit))["high", ]
  rbin <- roc(d$death, d$high, direction = "<", quiet = TRUE)
  class_rows[[length(class_rows) + 1L]] <- data.frame(marker = label[[m]], classification = "median", cutoff = med,
    n = nrow(d), events = sum(d$death), OR_high_vs_low = exp(rr["Estimate"]), OR_CI_lower = exp(rr["Estimate"] - 1.96 * rr["Std. Error"]), OR_CI_upper = exp(rr["Estimate"] + 1.96 * rr["Std. Error"]), p = rr["Pr(>|z|)"], AUC_binary = as.numeric(auc(rbin)))
  q <- quantile(d[[m]], c(.25, .5, .75), na.rm = TRUE); d[, quartile := cut(get(m), breaks = c(-Inf, q, Inf), labels = paste0("Q", 1:4), include.lowest = TRUE)]
  fitq <- glm(death ~ quartile, data = d, family = binomial)
  co <- coef(summary(fitq));
  for (lv in levels(d$quartile)) {
    if (lv == "Q1") next
    nm <- paste0("quartile", lv)
    class_rows[[length(class_rows) + 1L]] <- data.frame(marker = label[[m]], classification = "quartile", cutoff = paste(q, collapse = ";"),
      n = nrow(d), events = sum(d$death), OR_high_vs_low = exp(co[nm, "Estimate"]), OR_CI_lower = exp(co[nm, "Estimate"] - 1.96 * co[nm, "Std. Error"]), OR_CI_upper = exp(co[nm, "Estimate"] + 1.96 * co[nm, "Std. Error"]), p = co[nm, "Pr(>|z|)"], AUC_binary = NA_real_, quartile = lv)
  }
}
fwrite(rbindlist(class_rows, fill = TRUE), file.path(OUT, "median_quartile_classification.csv"))

writeLines(c("Extended exploratory analyses accompanying the manuscript.",
  "",
  "Contents: M1-M3 adjusted logistic ORs, bootstrap optimism-corrected Youden",
  "cutoffs, adjusted platelet RCS, subgroup paired-AUC forests and interaction",
  "contrasts, median/quartile analyses, seven-day CBC backfill, ICU severity-score",
  "benchmarks, and albumin/PNI sensitivity analyses. The adjusted platelet curve",
  "is manuscript Figure 4, stored as Figure4_platelet_rcs_adjusted here and as",
  "Figure4_platelet_rcs in the submission package.",
  "",
  "No Cox HRs are reported: old intervals started at hospital admission before",
  "the preoperative exposure and operation; postoperative event times were not",
  "constructed. These analyses are exploratory and do not replace primary",
  "paired-AUC analyses. ICU scores are postoperative, selected-subset benchmarks;",
  "seven-day and albumin/PNI analyses use different samples/time windows.",
  "",
  "Run scripts 19 then 20 with R 4.5.1 from the project parent, or set",
  "FRONTMED_PROJECT_ROOT. RA_ROOT can point explicitly to the primary analysis",
  "package. FRONTMED_EXTENDED_OUT overrides the default outputs/extended_analysis.",
  "Dependencies: data.table 1.18.4, pROC 1.19.0.1, DBI 1.3.0,",
  "RPostgres 1.4.10, rms 8.2-0, ggplot2 4.0.3. Script 19 reads restricted frozen",
  "local data; script 20 also uses the shared read-only database factory. No",
  "patient/stay identifiers, row-level records, credentials or logs are distributed."), file.path(OUT, "README.txt"))
cat("extended analyses complete; rows:", nrow(d), "events:", sum(d$death), "\n")
