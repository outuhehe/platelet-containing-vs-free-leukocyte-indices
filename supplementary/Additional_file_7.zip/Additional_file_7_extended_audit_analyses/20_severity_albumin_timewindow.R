suppressPackageStartupMessages({
  library(DBI)
  library(data.table)
  library(pROC)
})

PROJECT_ROOT <- normalizePath(Sys.getenv("FRONTMED_PROJECT_ROOT", unset = getwd()), winslash = "/", mustWork = TRUE)
RA_ROOT <- Sys.getenv("RA_ROOT", unset = file.path(PROJECT_ROOT, "reproducible_analysis"))
if (!file.exists(file.path(RA_ROOT, "R", "00_common.R"))) {
  if (file.exists(file.path(PROJECT_ROOT, "R", "00_common.R"))) RA_ROOT <- PROJECT_ROOT
  else stop("Could not find reproducible_analysis/R/00_common.R; set FRONTMED_PROJECT_ROOT to the project parent")
}
Sys.setenv(RA_ROOT = RA_ROOT)
source(file.path(RA_ROOT, "R", "00_common.R"))
OUT <- Sys.getenv("FRONTMED_EXTENDED_OUT", unset = file.path(PROJECT_ROOT, "outputs", "extended_analysis"))
DATA <- file.path(RA_ROOT, "outputs", "interim")
dir.create(OUT, recursive = TRUE, showWarnings = FALSE)
set.seed(20261120)

base <- fread(file.path(DATA, "cbc_export_v2.csv"), check.names = TRUE)
surv <- fread(file.path(DATA, "cbc_export_with_survival.csv"), check.names = TRUE)
roster <- fread(file.path(DATA, "cohort_roster_2376.csv"), check.names = TRUE)
complete <- base[is.finite(nlr) & is.finite(sii) & is.finite(siri) & is.finite(piv) & is.finite(plr)]
complete <- merge(complete, surv[, .(hadm_id, time_days, status)], by = "hadm_id")
complete <- merge(complete, roster[, .(hadm_id, admission_type)], by = "hadm_id")
complete[, death := as.integer(hospital_expire_flag)]
complete[, sex_f := factor(sex)]
complete[, adm_grp := factor(ifelse(grepl("EMER|URGENT", admission_type, ignore.case = TRUE), "emergency_urgent",
                                    ifelse(grepl("ELECTIVE", admission_type, ignore.case = TRUE), "elective", "other")))]

con <- connect_mimic()
on.exit(dbDisconnect(con), add = TRUE)

# Expanded seven-day laboratory window; restrict back to the frozen eligible cohort.
sql_path <- file.path(RA_ROOT, "sql", "cbc_export_v2.sql")
sql <- paste(readLines(sql_path, warn = FALSE, encoding = "UTF-8"), collapse = "\n")
if (!grepl("INTERVAL '3 days'", sql, fixed = TRUE)) stop("Expected 72-hour window token was not found.")
sql7 <- gsub("INTERVAL '3 days'", "INTERVAL '7 days'", sql, fixed = TRUE)
expanded <- as.data.table(dbGetQuery(con, sql7))
setnames(expanded, make.unique(names(expanded)))
expanded <- expanded[hadm_id %in% roster$hadm_id]
expanded <- expanded[is.finite(nlr) & is.finite(sii) & is.finite(siri) & is.finite(piv) & is.finite(plr)]
expanded <- merge(expanded, roster[, .(hadm_id)], by = "hadm_id")
delta_auc <- function(x, free, cont) {
  a <- roc(x$hospital_expire_flag, x[[free]], direction = "<", quiet = TRUE)
  b <- roc(x$hospital_expire_flag, x[[cont]], direction = "<", quiet = TRUE)
  as.numeric(auc(a) - auc(b))
}
window_rows <- list()
for (cmp in list(c("NLR_vs_SII", "nlr", "sii"), c("SIRI_vs_PIV", "siri", "piv"))) {
  z <- expanded[is.finite(get(cmp[2])) & is.finite(get(cmp[3]))]
  window_rows[[length(window_rows) + 1L]] <- data.frame(
    comparison = cmp[1], window = "72-hour frozen", n = if (cmp[1] == "NLR_vs_SII") 886L else 879L,
    events = 87L,
    delta_AUC_free_minus_containing = if (cmp[1] == "NLR_vs_SII") 0.109 else 0.087)
  window_rows[[length(window_rows) + 1L]] <- data.frame(
    comparison = cmp[1], window = "expanded 7-day", n = nrow(z), events = sum(z$hospital_expire_flag),
    delta_AUC_free_minus_containing = delta_auc(z, cmp[2], cmp[3]))
}
fwrite(rbindlist(window_rows), file.path(OUT, "time_window_backfill.csv"))

# First ICU stay per hospital admission; these scores benchmark a selected ICU subset.
score_sql <- paste0(
  "WITH first_icu AS (SELECT DISTINCT ON (hadm_id) subject_id, hadm_id, stay_id, intime ",
  "FROM mimiciv_icu.icustays ORDER BY hadm_id, intime, stay_id) ",
  "SELECT i.hadm_id, i.stay_id, i.intime, fs.sofa AS first_day_sofa, s.sapsii, a.apsiii ",
  "FROM first_icu i LEFT JOIN mimiciv_derived.first_day_sofa fs USING (stay_id) ",
  "LEFT JOIN (SELECT DISTINCT ON (stay_id) stay_id, sapsii FROM mimiciv_derived.sapsii ORDER BY stay_id, starttime) s USING (stay_id) ",
  "LEFT JOIN mimiciv_derived.apsiii a USING (stay_id) ",
  "WHERE i.hadm_id IN (", paste(roster$hadm_id, collapse = ","), ")")
scores <- as.data.table(dbGetQuery(con, score_sql))
score_dat <- merge(complete, scores[, .(hadm_id, first_day_sofa, sapsii, apsiii)], by = "hadm_id", all = FALSE)
score_rows <- list()
base_f <- death ~ age + sex_f + adm_grp + charlson
for (v in c("first_day_sofa", "sapsii", "apsiii")) {
  z <- score_dat[is.finite(get(v))]
  if (nrow(z) < 100 || sum(z$death) < 10) next
  fb <- glm(base_f, data = z, family = binomial)
  fs <- glm(update(base_f, paste(". ~ . +", v)), data = z, family = binomial)
  pb <- predict(fb, type = "response"); ps <- predict(fs, type = "response")
  ab <- as.numeric(auc(roc(z$death, pb, quiet = TRUE)))
  as <- as.numeric(auc(roc(z$death, ps, quiet = TRUE)))
  lr <- anova(fb, fs, test = "LRT")
  score_rows[[length(score_rows) + 1L]] <- data.frame(score = v, n = nrow(z), events = sum(z$death),
    base_AUC = ab, base_plus_score_AUC = as, delta_AUC = as - ab,
    LRT_p = lr$`Pr(>Chi)`[2])
}
fwrite(rbindlist(score_rows, fill = TRUE), file.path(OUT, "severity_score_benchmark.csv"))

# Albumin nearest to and no later than the selected preoperative CBC, within 72 h.
ids <- paste(roster$hadm_id, collapse = ",")
albumin <- as.data.table(dbGetQuery(con, paste0(
  "SELECT hadm_id, charttime, itemid, valuenum, valueuom FROM mimiciv_hosp.labevents ",
  "WHERE hadm_id IN (", ids, ") AND itemid IN (50862,53085,53138) ",
  "AND valuenum > 0 AND charttime IS NOT NULL")))
panel <- complete[, .(hadm_id, panel_time, alc, death)]
albumin <- merge(albumin, panel, by = "hadm_id", allow.cartesian = TRUE)
albumin <- albumin[charttime <= panel_time & charttime >= panel_time - 72 * 3600]
setorder(albumin, hadm_id, -charttime)
albumin <- albumin[, .SD[1], by = hadm_id]
albumin[, albumin_g_dl := fifelse(valueuom %in% c("g/dL", "gm/dL"), valuenum,
                                  fifelse(valueuom %in% c("g/L", "gm/L"), valuenum / 10, NA_real_))]
albumin[, pni := 10 * albumin_g_dl + 5 * alc]
nut_rows <- list()
for (v in c("albumin_g_dl", "pni")) {
  z <- albumin[is.finite(get(v)) & is.finite(death)]
  if (nrow(z) < 100 || sum(z$death) < 10) next
  f <- glm(death ~ scale(get(v)), data = z, family = binomial)
  ce <- coef(summary(f))[2, ]
  r <- roc(z$death, z[[v]], direction = ">", quiet = TRUE)
  nut_rows[[length(nut_rows) + 1L]] <- data.frame(marker = v, n = nrow(z), events = sum(z$death),
    OR_per_SD = exp(ce[1]), CI_lower = exp(ce[1] - 1.96 * ce[2]), CI_upper = exp(ce[1] + 1.96 * ce[2]),
    AUC = as.numeric(auc(r)))
}
fwrite(rbindlist(nut_rows, fill = TRUE), file.path(OUT, "albumin_pni_sensitivity.csv"))
cat("time-window, severity-score, albumin/PNI analyses complete; expanded eligible cohort rows:",
    nrow(expanded), "complete five-index rows:", nrow(expanded[complete.cases(nlr, sii, siri, piv, plr)]), "\n")
