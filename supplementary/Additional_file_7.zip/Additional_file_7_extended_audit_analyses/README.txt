Extended exploratory analyses for the current manuscript.

The original script-19/20 analyses and numerical tables are retained unchanged.
New script 21 adds cross-validated continuous NRI and IDI and component-wise /
index-wise winsorization at the 1st/99th and 2.5th/97.5th percentiles.

New aggregate files:
- reclassification_NRI_IDI.csv: 6 old-to-new model contrasts, 20 grouped 10-fold
  partitions, 500 full refit subject-cluster bootstrap confidence intervals.
- winsorized_paired_AUC.csv: raw and four transformed specifications; positive
  delta_AUC_free_minus_containing favours the platelet-free formula; 2,000
  clustered resamples with quantile re-estimation.
- winsorized_adjusted_OR.csv: common-sample M3 OR per SD log index, raw and
  all winsorization specifications, with Wald confidence intervals.
- NRI_IDI_winsorization_methods.txt: exact definitions and inference boundaries.

NRI/IDI risk comparisons are base versus base + index and base + containing
versus base + free. Positive NRI/IDI favours the new model. IDI is stored as
absolute probability, not percentage points. NRI event and non-event components
are separate columns. Partition SDs are not confidence intervals. These are
post-hoc exploratory metrics without multiplicity-adjusted inference or proof
of clinical utility. No clinical risk categories were specified.

Prediction-model admission coding matches script 16 (EMER-labelled, ELECTIVE,
other; URGENT in other); M3 associations match script 19 (EMER/URGENT combined).
Common-sample winsorization retains 879 stays/87 deaths and does not modify the
original primary comparisons. Component-wise caps precede formula construction;
independent index caps do not preserve the original multiplicative identities.

To reproduce script 21, set RA_ROOT to the extracted primary analysis package
after running stages 01-15, then run Rscript 21_reclassification_winsorization.R.
Optional settings are documented in the primary package README. Default output
is RA_ROOT/outputs/reclassification_winsorization; STUDY_NRI_OUT overrides it.
Dependencies for script 21 are base R stats/parallel only (R 4.5.1 used).

Original contents: M1-M3 adjusted OR, optimism-corrected Youden cutoffs,
adjusted platelet RCS, subgroup paired-AUC forests/interactions, median/quartile
analyses, seven-day backfill, first-ICU-day severity benchmarks and albumin/PNI.
Scripts 19 and 20 keep their original dependencies and paths. Script 20 uses the shared read-only DB factory.

No patient/stay identifiers, row-level data, exact patient times, credentials,
prediction vectors or local logs are distributed. No Cox HRs are reported.
